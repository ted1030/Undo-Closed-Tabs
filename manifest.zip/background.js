(async () => {
chrome.action.onClicked.addListener(tab => {
    chrome.sessions.getRecentlyClosed((sessions) => {
        if (sessions.length > 0) {
            chrome.sessions.restore(sessions[0].tab.sessionId);
        }
    });
});

let items = [];

let restore = async () => {
    let sessions = await chrome.sessions.getRecentlyClosed();
    if (sessions.length <= 0) 
        return;
    items = Object.fromEntries(sessions.filter(s => s?.tab).map((session) => [
        session.tab.sessionId,
        {
            title: session.tab.title,
            url: session.tab.url
        }
    ]));
    chrome.contextMenus.removeAll()

    top_items = Object.entries(items).reverse().slice(0, 5)
    sub_items = Object.entries(items).reverse().slice(5)
    if (top_items) {
        top_items.forEach((item) => {
            chrome.contextMenus.create({
                id: item[0],
                title: item[1].title,
                contexts: ["action"]
            });
        });
    }
    if (sub_items) {
        chrome.contextMenus.create({
            id: "closed-tabs",
            title: "▶",
            contexts: ["action"]
        });
        sub_items.forEach((item) => {
            chrome.contextMenus.create({
                parentId: "closed-tabs",
                id: item[0],
                title: item[1].title,
                contexts: ["action"]
            });
        });
    }
};
restore();

chrome.contextMenus.onClicked.addListener((info, tab) => chrome.sessions.restore(info.menuItemId))
chrome.sessions.onChanged.addListener(() => restore())

})()